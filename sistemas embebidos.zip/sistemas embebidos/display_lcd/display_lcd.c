#include "C:\Users\VAIOPC\Documents\sistemas embebidos\display_lcd\display_lcd.h"
  #ZERO_RAM

void config();
void code();
void main()
{
 config(); 
 code();
}
void config()
{

   setup_adc_ports(NO_ANALOGS|VSS_VDD);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_OFF);
   setup_timer_0(RTCC_INTERNAL);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
//Setup_Oscillator parameter not selected from Intr Oscillator Config tab

   // TODO: USER CODE!!

}
void code()
{
  while(true)
  {
 output_HIGH(PIN_A0);

  }
}
