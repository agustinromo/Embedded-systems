#include "C:\Users\VAIOPC\Documents\sistemas embebidos\expermento1\prende_led.h"
  #ZERO_RAM


void main()
{

   setup_adc_ports(NO_ANALOGS|VSS_VDD);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_comparator(NC_NC);
   setup_vref(FALSE);

   // TODO: USER CODE!! 
   while(true){
   output_high(PIN_A1); 
   delay_ms(1000); 
   output_low(PIN_A1); 
   delay_ms(1000); 
   }

}
