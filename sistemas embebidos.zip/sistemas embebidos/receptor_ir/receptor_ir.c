#include "C:\Users\VAIOPC\Documents\sistemas embebidos\receptor_ir\receptor_ir.h"
  #ZERO_RAM
 int b; //b=boton
#int_EXT 
void EXT_isr(void)
{ 
 b++; //boton estar� contando el numero de veces que es presionado
 if(b == 5)
 {
  b=0;
 } 
 clear_interrupt(INT_EXT);
}
void main()
{

   setup_adc_ports(NO_ANALOGS|VSS_VDD);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_OFF);
   setup_timer_0(RTCC_INTERNAL);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
//Setup_Oscillator parameter not selected from Intr Oscillator Config tab 
 EXT_INT_EDGE(L_TO_H);   // Cambio de estado de bajo a alto //
   enable_interrupts(INT_EXT);  //Habilitador de interrupcion//
   enable_interrupts(INT_EXT1);
   enable_interrupts(INT_EXT2);
   enable_interrupts(GLOBAL);   // Habilitador interrupcion modo global//
   set_tris_b(0xE0);   
   // TODO: USER CODE!! 
   while(true)
   {
    if(b == 0) 
    { 
     output_low(PIN_A0);
     output_low(PIN_A1);
     output_low(PIN_A2); 
     output_low(PIN_A3);
    }
    if(b == 1) 
    { 
     output_high(PIN_A0);
     output_low(PIN_A1);
     output_low(PIN_A2); 
     output_low(PIN_A3);
    }
    if(b == 2) 
    { 
     output_low(PIN_A0);
     output_high(PIN_A1);
     output_low(PIN_A2); 
     output_low(PIN_A3);
    } 
    if(b == 3) 
    { 
     output_low(PIN_A0);
     output_low(PIN_A1);
     output_high(PIN_A2); 
     output_low(PIN_A3);
    } 
    if(b == 4) 
    { 
     output_low(PIN_A0);
     output_low(PIN_A1);
     output_low(PIN_A2); 
     output_high(PIN_A3);
    }
   }
}
