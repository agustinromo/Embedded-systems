#include "C:\Users\VAIOPC\Documents\sistemas embebidos\pwm\pwm_2550.h"
  #ZERO_RAM
int16 pot=0;
void main()
{
   setup_adc_ports(AN0|VSS_VDD);  
   setup_adc(ADC_CLOCK_DIV_2); 
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_OFF);
   setup_timer_0(RTCC_INTERNAL);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DIV_BY_16,255,1);
   setup_timer_3(T3_DISABLED|T3_DIV_BY_1);
   setup_ccp1(CCP_PWM); 
   setup_ccp2(CCP_PWM);
   set_pwm1_duty(0);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE); 
//Setup_Oscillator parameter not selected from Intr Oscillator Config tab
   // TODO: USER CODE!! 
   while(true){ 
   set_adc_channel(0); 
   delay_us(20);
   pot=read_adc();   
   set_pwm1_duty(pot); 
   }
}
