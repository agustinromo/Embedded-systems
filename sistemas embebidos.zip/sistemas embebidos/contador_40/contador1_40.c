#include "C:\Users\VAIOPC\Documents\sistemas embebidos\experimento5\contador1_40.h"
  #ZERO_RAM 
int contador=0; 
int16 contar=0; 
#INT_TIMER0
void  TIMER0_isr(void) 
{
contar++;
if(contar==3000){
contar=0; 
contador++;
}
set_timer0 (131); //interrupcion interna
}
void main()
{
   setup_adc_ports(NO_ANALOGS);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_psp(PSP_DISABLED);
   setup_spi(SPI_SS_DISABLED);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE); 
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_4|RTCC_8_bit);      
   enable_interrupts(INT_TIMER0);
   set_timer0 (131); 
   enable_interrupts(GLOBAL);
   // TODO: USER CODE!! 
   while(true)
   {        
           loop:
            //contador=contador+1; 
            lcd_init(); 
            lcd_gotoxy(4,2);
            printf(lcd_putc,"%i",contador); 
             switch(contador)
             {
              case 5: 
              output_high(PIN_A0); 
              contador=0; 
              goto loop;
              break; 
              
              case 1: 
              output_low(PIN_A0); 
              break; 
             }
  }
}
