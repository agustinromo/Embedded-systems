#include "C:\Users\VAIOPC\Documents\sistemas embebidos\experimento5\contador_40.h"
  #ZERO_RAM 
int8 contador=0; 
void main()
{
   setup_adc_ports(NO_ANALOGS);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_psp(PSP_DISABLED);
   setup_spi(SPI_SS_DISABLED);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE); 
   // TODO: USER CODE!! 
   while(true)
   {   
            contador++;
            lcd_init();  
            lcd_gotoxy(4,2); 
            printf(lcd_putc,"%i",contador); 
/////this is what is going to happen after the end of the counter///
      switch(contador){ 
      case 3: output_high(PIN_A0); 
              contador=0;
              break; 
      case 0: output_low(PIN_A0); 
              break;
      }
  }
}
