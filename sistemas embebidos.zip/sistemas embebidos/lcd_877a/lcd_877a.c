#include "C:\Users\VAIOPC\Documents\sistemas embebidos\experimento4\lcd_877a.h"
  #ZERO_RAM
  #include <lcd.c>
 
  int a,b,c,d,buton;
  int num,num2,num3; 
  int valor1,valor2,valor3,valor4; 
  #int_EXT
void  EXT_isr(void) 
{
   buton++;
  
   if(buton==4)
   {
     buton=0;
   }
   clear_interrupt(INT_EXT);  //se ser necesario se limpia el flag de rb
}
  
void main()
{

   setup_adc_ports(NO_ANALOGS);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_psp(PSP_DISABLED);
   setup_spi(SPI_SS_DISABLED);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE); 
    EXT_INT_EDGE(L_TO_H);   // Cambio de estado de bajo a alto //
   enable_interrupts(INT_EXT);  //// Habilita interrupcion///
   enable_interrupts(GLOBAL); 

   // TODO: USER CODE!! 
   buton = input(PIN_B0); 
   while(true){ 
   a = input(PIN_A0); 
   b = input(PIN_B1); 
   c = input(PIN_B2); 
   d = input(PIN_B3); 
   
     if(buton == 0){
     lcd_init(); 
     lcd_gotoxy(1,1);
     printf(lcd_putc,"hola"); 
     //delay_ms(200); 
     lcd_gotoxy(1,2);
     //printf(lcd_putc,"%i",num); 
     delay_ms(200); 
     }
     if(buton == 1)
     { 
     if(a==1){
    valor1=1;
    } 
    if(b==1){
    valor2=2;
    } 
    if(c==1){ 
    valor3=4;
    } 
    if(d==1){ 
    valor4=8;
    } 
    /////// 
    if(a==0){
    valor1=0;
    } 
    if(b==0){
    valor2=0;
    } 
    if(c==0){ 
    valor3=0;
    } 
    if(d==0){ 
    valor4=0;
    } 
      num=valor1+valor2+valor3+valor4; 
      lcd_init(); 
        lcd_gotoxy(4,1);
        printf(lcd_putc,"%i",num);
   }  
   if(buton == 2){
   if(a==1){
    valor1=1;
    } 
    if(b==1){
    valor2=2;
    } 
    if(c==1){ 
    valor3=4;
    } 
    if(d==1){ 
    valor4=8;
    } 
    /////// 
    if(a==0){
    valor1=0;
    } 
    if(b==0){
    valor2=0;
    } 
    if(c==0){ 
    valor3=0;
    } 
    if(d==0){ 
    valor4=0;
    } 
      num2=valor1+valor2+valor3+valor4; 
      lcd_init(); 
        lcd_gotoxy(4,1);
        printf(lcd_putc,"%i",num2);
     
   } 
   if(buton == 3){ 
   if(a==1){
    valor1=1;
    } 
    if(b==1){
    valor2=2;
    } 
    if(c==1){ 
    valor3=4;
    } 
    /////// 
    if(a==0){
    valor1=0;
    } 
    if(b==0){
    valor2=0;
    } 
    if(c==0){ 
    valor3=0;
    } 
    num3=valor1+valor2+valor3;
   if(num3 == 0){
        lcd_init(); 
        lcd_gotoxy(1,1);
        printf(lcd_putc,"suma"); 
        //delay_ms(200); 
        lcd_gotoxy(1,2);
        printf(lcd_putc,"%i",num+num2); 
   } 
   if(num3 == 1){
        lcd_init(); 
        lcd_gotoxy(1,1);
        printf(lcd_putc,"res"); 
        //delay_ms(200); 
        lcd_gotoxy(1,2);
        printf(lcd_putc,"%i",num-num2); 
   } 
    if(num3 == 2){
        lcd_init(); 
        lcd_gotoxy(1,1);
        printf(lcd_putc,"mult"); 
        //delay_ms(200); 
        lcd_gotoxy(1,2);
        printf(lcd_putc,"%i",num*num2); 
   }  
    if(num3 == 3){ 
        lcd_init(); 
        lcd_gotoxy(1,1);
        printf(lcd_putc,"div"); 
        //delay_ms(200); 
        lcd_gotoxy(1,2);
        printf(lcd_putc,"%i",num/num2); 
        if(num2 == 0)
        {  
         lcd_init(); 
        lcd_gotoxy(1,1);
        printf(lcd_putc,"error"); 
        }
   } 
    
   }
   } 
}
 //lcd_init(); 
      //lcd_gotoxy(4,1);
      //printf(lcd_putc,"%i",num); 
     //delay_ms(200); 
     //lcd_gotoxy(4,2);
     //printf(lcd_putc,"%i",num2); 
     //delay_ms(200);
