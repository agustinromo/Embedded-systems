#include "C:\Users\VAIOPC\Documents\sistemas embebidos\semafiro\semaforo.h"
  #ZERO_RAM

#int_EXT
void int_rb0() 
{ 
  output_low(PIN_A1); 
  output_low(PIN_A0);
  output_high(PIN_A2); 
  time;
  output_low(PIN_A2); 
} 
#int_EXT1
void int_rb1() 
{ 
  output_low(PIN_A6); 
  output_low(PIN_A3);
  output_high(PIN_A5); 
  time;
  output_low(PIN_A5); 
} 

void main()
{
   setup_adc_ports(NO_ANALOGS|VSS_VDD);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_OFF);
   setup_timer_0(RTCC_INTERNAL);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   EXT_INT_EDGE(H_TO_L);   // Cambio de estado de alto a bajo // 
   //port_b_pullups(true);
   enable_interrupts(INT_EXT);
   enable_interrupts(INT_EXT1); 
   enable_interrupts(INT_EXT2);
   enable_interrupts(GLOBAL);  //Interrupciones abilitadas en forma global
   set_tris_b(0b00000011);//Puertos B0 y B1 han sido activados para recibir informacion
   
   // TODO: USER CODE!! 
   while (true)
   { 
   //Semaforo 1 en funcion y semaforo 2 en alto
   output_high(PIN_A0); output_high(PIN_A5); 
   verde;               rojo; 
                                              
   output_high(PIN_A0); 
   fastverde; 
   output_low(PIN_A0); 
   fastverde; 
   output_high(PIN_A0);  
   fastverde; 
   output_low(PIN_A0); 
   fastverde; 
   output_high(PIN_A0); 
   fastverde; 
   output_low(PIN_A0); 
   fastverde; 
   output_high(PIN_A0); 
   fastverde; 
   output_low(PIN_A0); 
   fastverde; 
   output_high(PIN_A0); 
   fastverde; 
   output_low(PIN_A0); 
   fastverde;           
   ////////////////////////////////////////////////////////////////////////////
   //Semaforo 2 en funcion y semaforo 1 en alto
   output_high(PIN_A1); 
   amarillo; 
   output_low(PIN_A1);    output_low(PIN_A5);
   output_high(PIN_A2);   output_high(PIN_A3); 
   rojo;                  verde; 
   
   output_high(PIN_A3); 
   fastverde; 
   output_low(PIN_A3); 
   fastverde; 
   output_high(PIN_A3); 
   fastverde; 
   output_low(PIN_A3); 
   fastverde; 
   output_high(PIN_A3); 
   fastverde; 
   output_low(PIN_A3); 
   fastverde; 
   output_high(PIN_A3); 
   fastverde; 
   output_low(PIN_A3); 
   fastverde; 
   output_high(PIN_A3); 
   fastverde; 
   output_low(PIN_A3); 
   fastverde; 
   output_high(PIN_A6); 
   amarillo; 
   output_low(PIN_A6);  output_low(PIN_A2);  
  }
}
