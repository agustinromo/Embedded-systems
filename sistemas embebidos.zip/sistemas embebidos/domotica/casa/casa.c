#include "C:\Users\VAIOPC\Documents\sistemas embebidos\domotica\casa\casa.h"
  #ZERO_RAM
int8 sensor,sensor1=0;
void main()
{
   setup_adc_ports(NO_ANALOGS|VSS_VDD);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_OFF);
   setup_timer_0(RTCC_INTERNAL);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
//Setup_Oscillator parameter not selected from Intr Oscillator Config tab
   // TODO: USER CODE!! 
   set_tris_b(0xff);
   while(true)
   {
    if(i2c_isr_state() ==0x08)
    { 
     i2c_write(sensor1);
    } 
   sensor = input(PIN_A5); ///sensores de movimiento
   sensor1 = input(PIN_A3); 
   ///luz del ba�o
    if(sensor == 1)
    { 
     output_high(PIN_A0); 
     delay_ms(4000); 
     output_low(PIN_A0); 
    } 
    ///luz y alarma de cochera
     if(sensor1 == 1) 
     {
      output_high(PIN_A1); 
      output_high(PIN_A2);
      delay_ms(2000); 
     }
     else 
     { 
      output_low(PIN_A0); 
      output_low(PIN_A1); 
      output_low(PIN_A2);
     } 
   }
}
