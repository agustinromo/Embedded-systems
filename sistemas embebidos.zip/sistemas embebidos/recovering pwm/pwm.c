#include "C:\Users\VAIOPC\Documents\sistemas embebidos\recovering pwm\pwm.h"
  #ZERO_RAM

int16 duty1,duty2=0; //asi se llaman los potenciometros
int Timer2,Poscaler;
void main()
{
   Timer2=249;
   Poscaler=1; 
   setup_timer_2(t2_div_by_4,Timer2,Poscaler); 
   setup_ccp1(ccp_pwm); 
   setup_ccp2(ccp_pwm); 
   setup_adc_ports(sAN0|sAN1|VSS_VDD); //declaracion de los dos puertos analog in 0 y 1
   setup_adc(adc_clock_internal);
   // TODO: USER CODE!!  
 while(true){ 
 ///////pot1///////
 set_adc_channel(0); 
 delay_us(100); 
 duty1=read_adc(); //el primer potenciometro va a la analog in 0
 set_pwm1_duty(duty1); //el dato con salida pwm depender� de la lectura del primer potenciometro
 ///////pot2///////
 set_adc_channel(1); 
 delay_us(100); 
 duty2=read_adc(); //el segundo potenciometro va a la analog in 1
 set_pwm2_duty(duty2);  //el dato con salida pwm depender� de la lectura del segundo potenciometro
 } 
}
