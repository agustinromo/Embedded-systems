#include "C:\Users\VAIOPC\Documents\sistemas embebidos\recovering pwm\pwm_16f877a\pwm_877a.h"
  #ZERO_RAM

int16 duty1,duty2=0; 
int Timer2,Poscaler;
void main()
{
   Timer2=249;
   Poscaler=1; 
   setup_timer_2(T2_DIV_BY_16,255,1);    // 819 us overflow 
   setup_ccp1(ccp_pwm); 
   setup_ccp2(ccp_pwm); 
   set_pwm1_duty(0);        
   set_pwm2_duty(0);
   setup_adc_ports(all_analog);
   setup_adc(adc_clock_internal);

   // TODO: USER CODE!! 
   while(true){ 
 ///////pot1///////
 set_adc_channel(0); 
 delay_us(100); 
 duty1=read_adc(); 
 set_pwm1_duty(duty1); 
 ///////pot2///////
 set_adc_channel(2); 
 delay_us(100); 
 duty2=read_adc(); 
 set_pwm2_duty(duty2); 
 } 
}
